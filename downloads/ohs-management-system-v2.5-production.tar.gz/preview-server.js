#!/usr/bin/env node

// Simple production preview server for OHS Management System
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PORT = 8080;
const DIST_DIR = path.join(__dirname, 'dist');

// MIME types for different file extensions
const MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
};

// Get MIME type based on file extension
function getMimeType(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    return MIME_TYPES[ext] || 'application/octet-stream';
}

// Serve static files
function serveFile(filePath, response) {
    fs.readFile(filePath, (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // File not found, serve index.html for SPA routing
                serveFile(path.join(DIST_DIR, 'index.html'), response);
            } else {
                response.writeHead(500, { 'Content-Type': 'text/plain' });
                response.end('Internal Server Error');
            }
        } else {
            const mimeType = getMimeType(filePath);
            response.writeHead(200, { 
                'Content-Type': mimeType,
                'Cache-Control': 'public, max-age=3600' // Cache for 1 hour
            });
            response.end(data);
        }
    });
}

// Create HTTP server
const server = http.createServer((request, response) => {
    // Add security headers
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('X-Frame-Options', 'DENY');
    response.setHeader('X-XSS-Protection', '1; mode=block');
    
    // Parse URL
    const requestUrl = new URL(request.url, `http://${request.headers.host}`);
    let filePath = path.join(DIST_DIR, requestUrl.pathname);
    
    // Remove trailing slash for directory requests
    if (filePath.endsWith('/')) {
        filePath = filePath.slice(0, -1);
    }
    
    // If the path is just the root, serve index.html
    if (requestUrl.pathname === '/') {
        filePath = path.join(DIST_DIR, 'index.html');
    }
    
    // Check if file exists
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            // File not found, serve index.html for SPA routing
            serveFile(path.join(DIST_DIR, 'index.html'), response);
        } else {
            serveFile(filePath, response);
        }
    });
});

// Start server
server.listen(PORT, () => {
    console.log(`🚀 OHS Management System Preview Server`);
    console.log(`📊 Application: OHS MS Audit & Site Audit Tool v2.5`);
    console.log(`🌐 Server running at: http://localhost:${PORT}`);
    console.log(`📁 Serving files from: ${DIST_DIR}`);
    console.log(`⚡ Production build preview`);
    console.log(`\n🔍 Testing Checklist:`);
    console.log(`   ✅ Application loads without errors`);
    console.log(`   ✅ Charts display correctly`);
    console.log(`   ✅ Site comparison works`);
    console.log(`   ✅ Report generation functions`);
    console.log(`   ✅ Mobile responsiveness`);
    console.log(`\n💡 Press Ctrl+C to stop the server\n`);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 Stopping preview server...');
    server.close(() => {
        console.log('✅ Server stopped');
        process.exit(0);
    });
});

// Handle errors
server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use. Please use a different port.`);
        process.exit(1);
    } else {
        console.error('❌ Server error:', err);
        process.exit(1);
    }
});