#!/bin/bash

# OHS Management System Deployment Script
# This script prepares and deploys the OHS Management System for production

set -e

echo "🚀 Starting OHS Management System Deployment..."

# Configuration
APP_NAME="ohs-management-system"
BUILD_DIR="dist"
DEPLOY_DIR="/var/www/html/$APP_NAME"
BACKUP_DIR="/var/backups/$APP_NAME"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   log_error "This script must be run as root"
   exit 1
fi

# Check if build directory exists
if [ ! -d "$BUILD_DIR" ]; then
    log_error "Build directory '$BUILD_DIR' not found. Please run 'npm run build' first."
    exit 1
fi

# Create backup directory if it doesn't exist
mkdir -p "$BACKUP_DIR"

# Create deployment directory if it doesn't exist
mkdir -p "$DEPLOY_DIR"

# Backup existing deployment if it exists
if [ -d "$DEPLOY_DIR" ]; then
    log_info "Creating backup of existing deployment..."
    BACKUP_NAME="$APP_NAME-$(date +%Y%m%d-%H%M%S)"
    cp -r "$DEPLOY_DIR" "$BACKUP_DIR/$BACKUP_NAME"
    log_info "Backup created at: $BACKUP_DIR/$BACKUP_NAME"
fi

# Deploy new build
log_info "Deploying new build..."
cp -r "$BUILD_DIR"/* "$DEPLOY_DIR/"

# Set proper permissions
log_info "Setting permissions..."
chown -R www-data:www-data "$DEPLOY_DIR"
chmod -R 755 "$DEPLOY_DIR"

# Create .htaccess for clean URLs and caching
cat > "$DEPLOY_DIR/.htaccess" << 'EOF'
# Enable rewrite engine
RewriteEngine On

# Cache static assets for better performance
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 year"
    ExpiresByType application/javascript "access plus 1 year"
    ExpiresByType image/svg+xml "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
</IfModule>

# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>

# Security headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "DENY"
    Header set X-XSS-Protection "1; mode=block"
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"
</IfModule>

# Handle SPA routing (fallback to index.html)
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ /index.html [L]
EOF

# Create deployment info file
cat > "$DEPLOY_DIR/deployment-info.txt" << EOF
OHS Management System Deployment Information
==========================================

Deployment Date: $(date)
Version: 2.5
Build Hash: $(git rev-parse --short HEAD 2>/dev/null || echo "unknown")
Application: OHS MS Audit & Site Audit Tool
Framework: Vite + Chart.js
Node Version: $(node --version)
NPM Version: $(npm --version)

Files Deployed:
$(ls -la "$DEPLOY_DIR")

Deployment Notes:
- Chart.js v3.7.1 with simplified loading mechanism
- All chart types working: Stacked Bar, Grouped Bar, Radar
- Site performance comparison functionality included
- Executive dashboard with real-time metrics
- Report generation with HTML export capabilities
- Responsive design for mobile and desktop

For support, please contact the development team.
EOF

# Restart web server (assuming Apache)
log_info "Restarting web server..."
if command -v systemctl &> /dev/null; then
    systemctl reload apache2 || systemctl reload httpd || log_warn "Could not restart web server. Please restart manually."
elif command -v service &> /dev/null; then
    service apache2 reload || service httpd reload || log_warn "Could not restart web server. Please restart manually."
fi

log_info "✅ Deployment completed successfully!"
log_info "Application is now available at: http://localhost/$APP_NAME"
log_info "Deployment info available at: $DEPLOY_DIR/deployment-info.txt"

# Show deployment summary
echo ""
echo "📊 Deployment Summary:"
echo "   Application: OHS Management System"
echo "   Version: 2.5"
echo "   Deployed to: $DEPLOY_DIR"
echo "   Backup: $BACKUP_DIR/$BACKUP_NAME"
echo "   URL: http://localhost/$APP_NAME"
echo ""
echo "🔧 Next Steps:"
echo "   1. Verify the application is accessible at the URL above"
echo "   2. Test all features (charts, reports, site comparison)"
echo "   3. Check browser console for any errors"
echo "   4. Update DNS if deploying to a custom domain"
echo ""
echo "📞 For issues, check the deployment logs or contact support."