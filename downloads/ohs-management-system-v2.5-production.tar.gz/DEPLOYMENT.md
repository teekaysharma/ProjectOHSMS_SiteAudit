# OHS Management System - Deployment Guide

## Overview

The OHS Management System is a comprehensive Occupational Health and Safety audit tool that enables organizations to conduct safety management system audits and site safety audits. This guide provides instructions for deploying the application to production.

## Application Details

- **Name**: OHS MS Audit & Site Audit Tool
- **Version**: 2.5
- **Framework**: Vite + Chart.js
- **Type**: Single Page Application (SPA)
- **Build Tool**: Vite 5.4.20
- **Chart Library**: Chart.js 3.7.1

## Prerequisites

### System Requirements
- **Web Server**: Apache 2.4+ or Nginx 1.18+
- **Node.js**: 16.x or higher (for build process only)
- **npm**: 8.x or higher (for build process only)
- **SSL Certificate**: Recommended for production
- **Disk Space**: Minimum 50MB

### Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Build Process

### 1. Install Dependencies
```bash
npm install
```

### 2. Create Production Build
```bash
npm run build
```

This creates an optimized production build in the `dist/` directory with:
- Minified JavaScript and CSS
- Optimized asset loading
- Tree-shaking to remove unused code
- Source maps for debugging

### 3. Verify Build
Check that the build completed successfully:
```bash
ls -la dist/
```

Expected output should include:
- `index.html` - Main application file
- `assets/` - Directory with optimized JS and CSS files

## Deployment Methods

### Method 1: Manual Deployment (Apache)

1. **Copy Build Files**
```bash
sudo cp -r dist/* /var/www/html/ohs-management-system/
```

2. **Set Permissions**
```bash
sudo chown -R www-data:www-data /var/www/html/ohs-management-system
sudo chmod -R 755 /var/www/html/ohs-management-system
```

3. **Configure Apache**
Create or edit the virtual host configuration:
```apache
<VirtualHost *:80>
    ServerName your-domain.com
    DocumentRoot /var/www/html/ohs-management-system
    
    <Directory /var/www/html/ohs-management-system>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

4. **Enable Site**
```bash
sudo a2ensite ohs-management-system
sudo systemctl reload apache2
```

### Method 2: Automated Deployment

Use the provided deployment script:
```bash
sudo ./deploy.sh
```

This script will:
- Create a backup of the existing deployment
- Copy the new build files
- Set proper permissions
- Configure Apache settings
- Restart the web server

### Method 3: Nginx Deployment

1. **Copy Build Files**
```bash
sudo cp -r dist/* /usr/share/nginx/html/ohs-management-system/
```

2. **Configure Nginx**
Create a configuration file at `/etc/nginx/sites-available/ohs-management-system`:
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /usr/share/nginx/html/ohs-management-system;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Cache static assets
    location ~* \.(css|js|ico|png|jpg|jpeg|gif|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Handle SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

3. **Enable Site**
```bash
sudo ln -s /etc/nginx/sites-available/ohs-management-system /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Method 4: Docker Deployment

1. **Create Dockerfile**
```dockerfile
FROM nginx:alpine

COPY dist/ /usr/share/nginx/html/
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
```

2. **Build Docker Image**
```bash
docker build -t ohs-management-system:latest .
```

3. **Run Container**
```bash
docker run -d -p 80:80 --name ohs-management-system ohs-management-system:latest
```

## SSL Configuration (Recommended)

### Using Let's Encrypt with Apache

1. **Install Certbot**
```bash
sudo apt update
sudo apt install certbot python3-certbot-apache
```

2. **Obtain Certificate**
```bash
sudo certbot --apache -d your-domain.com
```

3. **Verify Auto-renewal**
```bash
sudo certbot renew --dry-run
```

### Using Let's Encrypt with Nginx

1. **Install Certbot**
```bash
sudo apt update
sudo apt install certbot python3-certbot-nginx
```

2. **Obtain Certificate**
```bash
sudo certbot --nginx -d your-domain.com
```

## Post-Deployment Verification

### 1. Application Access
Open a browser and navigate to your deployment URL. You should see:
- Application title: "OHS Management System"
- Login/landing screen
- No JavaScript errors in browser console

### 2. Feature Testing
Test the following features:

#### Dashboard Features
- Executive Summary Dashboard loads
- Performance charts display correctly
- Metrics show proper values

#### Chart Functionality
- Navigate to Reports tab
- Test different chart types:
  - Stacked Bar charts
  - Grouped Bar charts
  - Radar charts
- Verify Chart.js loads without errors

#### Site Comparison
- Select multiple sites for comparison
- Verify comparison charts work
- Test drill-down functionality

#### Report Generation
- Test executive report generation
- Verify HTML export functionality
- Check report customization options

### 3. Browser Console Check
Open browser developer tools and check for:
- ✅ No Chart.js loading errors
- ✅ No JavaScript runtime errors
- ✅ All resources load successfully

### 4. Mobile Responsiveness
Test on different screen sizes:
- Desktop (1920x1080)
- Tablet (768x1024)
- Mobile (375x667)

## Performance Optimization

### Caching Strategy
The application includes built-in caching headers:
- CSS and JS files: 1 year cache
- Images: 1 year cache
- HTML: No cache (for SPA routing)

### CDN Integration
For better performance, consider using a CDN:
1. Upload static assets to CDN
2. Update asset URLs in the build
3. Configure CDN caching rules

### Compression
Enable gzip compression on your web server to reduce file sizes:
- Apache: `mod_deflate`
- Nginx: `gzip` module

## Security Considerations

### Web Server Security
- Remove server version headers
- Implement rate limiting
- Use HTTPS in production
- Regular security updates

### Application Security
- Input validation is implemented
- XSS protection is built-in
- CSRF protection for forms
- Secure cookie handling

### Data Protection
- All data is stored client-side
- No server-side database required
- Export functionality for data backup
- Local storage for session data

## Monitoring and Maintenance

### Log Monitoring
Monitor web server logs for:
- 404 errors (missing assets)
- 500 errors (server issues)
- Access patterns and performance

### Performance Monitoring
Track:
- Page load times
- Resource loading times
- User interaction performance

### Backup Strategy
- Regular backups of deployment files
- Version control for application code
- Database backups (if implemented)

## Troubleshooting

### Common Issues

#### 1. White Screen or Blank Page
**Cause**: JavaScript errors or missing assets
**Solution**:
- Check browser console for errors
- Verify all assets are accessible
- Check web server error logs

#### 2. Charts Not Loading
**Cause**: Chart.js loading issues
**Solution**:
- Verify Chart.js is loaded in browser
- Check for JavaScript errors
- Ensure assets are properly served

#### 3. Site Comparison Not Working
**Cause**: Data or JavaScript issues
**Solution**:
- Check browser console for errors
- Verify site data is available
- Test with sample data

#### 4. Reports Not Generating
**Cause**: Browser security or JavaScript issues
**Solution**:
- Check popup blocker settings
- Verify JavaScript functions exist
- Test in different browsers

### Support

For deployment issues:
1. Check this documentation
2. Review browser console errors
3. Check web server logs
4. Contact development team

## Version History

### Version 2.5 (Current)
- ✅ Fixed Chart.js loading issues
- ✅ Simplified module loading mechanism
- ✅ Enhanced site comparison functionality
- ✅ Improved error handling
- ✅ Performance optimizations

### Version 2.4
- Added executive dashboard
- Enhanced report generation
- Mobile responsiveness improvements

### Version 2.3
- Initial Chart.js integration
- Site comparison features
- Basic audit functionality

## Contact Information

For support or questions about deployment:
- **Development Team**: [Contact Information]
- **Documentation**: [Documentation URL]
- **Issues**: [Issue Tracker URL]
- **Community**: [Community Forum URL]

---

*This deployment guide is for version 2.5 of the OHS Management System. Please ensure you are using the correct version of the application and documentation.*